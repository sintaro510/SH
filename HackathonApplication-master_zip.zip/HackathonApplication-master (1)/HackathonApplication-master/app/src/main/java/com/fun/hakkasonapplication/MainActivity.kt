package com.`fun`.hakkasonapplication

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import com.`fun`.hakkasonapplication.databinding.ActivityMainBinding
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.URL
import java.text.SimpleDateFormat
import java.util.*

private var resultText = ""
private var placeLat = 35.689499
private var placeLon = 139.691711

class MainActivity : AppCompatActivity() {
    lateinit var binding : ActivityMainBinding
    private var resultText = ""
    private var placeLat = 35.689499
    private var placeLon = 139.691711
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.button.setOnClickListener {
            // 天気と時刻を取得
            getWeatherNews()
            // 3秒間処理を止める
            Thread.sleep(3000)
            // 結果をtextViewに表示
            binding.textView3.text = resultText


        }

        //１）Viewの取得：メッセージを書く
        val btnwrite: Button = findViewById(R.id.btnWrite)

        //２）ボタンを押したらメッセージを書く画面へ
        btnwrite.setOnClickListener {
            val intent = Intent(this, SecondActivity::class.java)
            startActivity(intent)
        }

        val btnread: Button = findViewById(R.id.btnRead)

        btnread.setOnClickListener {
            val intent = Intent(this, MapsActivity::class.java)
            startActivity(intent)
        }
    }

    // unixtimeからフォーマットの日付に変換
    private fun unixTimeChange(unixTime: String): String {
        var sdf = SimpleDateFormat("yyyy/MM/dd HH:mm")
        var nowTime = Date(unixTime.toInt() * 1000L)
        return sdf.format(nowTime)
    }


    private fun getWeatherNews(): Job = GlobalScope.launch {
        // 結果を初期化
        resultText = ""
        // APIを使う際に必要なKEY
        var API_KEY = "fb917168411ee4479ef479755b143630"
        // URL。場所と言語・API_KEYを添付
        var API_URL = "https://api.openweathermap.org/data/2.5/onecall?" +
                "lat=" + placeLat + "&" +
                "lon=" + placeLon + "&" +
                "lang=" + "ja" + "&" +
                "APPID=" + API_KEY
        var url = URL(API_URL)
        //APIから情報を取得する.
        var br = BufferedReader(InputStreamReader(url.openStream()))
        // 所得した情報を文字列化
        var str = br.readText()
        //json形式のデータとして識別
        var json = JSONObject(str)
        // hourlyの配列を取得
        var hourly = json.getJSONArray("hourly")

        // 十時間分の天気予報を取得

            var firstObject = hourly.getJSONObject(0)
            //var weatherList = firstObject.getJSONArray("deg").getJSONObject(0)
            // unixtime形式で保持されている時刻を取得
            var time = firstObject.getString("dt")
            // 天気を取得
            //var descriptionText = weatherList.getString("")
            var wind = firstObject.getString("wind_deg").toInt()
            resultText += "${unixTimeChange(time)}  $wind \n\n"
        var wd = ""
        var rd = 360
        if(wind < 1*rd/32 || wind >= 31*rd/32) {
            wd = "北";
        }else if(wind < 3*rd/32) {
            wd = "北北東";
        }else if(wind < 5*rd/32) {
            wd = "北東";
        }else if(wind < 7*rd/32) {
            wd = "東北東";
        }else if(wind < 9*rd/32) {
            wd = "東";
        }else if(wind < 11*rd/32) {
            wd = "東南東";
        }else if(wind < 13*rd/32) {
            wd = "南東";
        }else if(wind < 15*rd/32) {
            wd = "南南東";
        }else if(wind < 17*rd/32) {
            wd = "南";
        }else if(wind < 19*rd/32) {
            wd = "南南西";
        }else if(wind < 21*rd/32) {
            wd = "南西";
        }else if(wind < 23*rd/32) {
            wd = "西南西";
        }else if(wind < 25*rd/32) {
            wd = "西";
        }else if(wind < 27*rd/32) {
            wd = "西北西";
        }else if(wind < 29*rd/32) {
            wd = "北西";
        }else if(wind < 31*rd/32) {
            wd = "北北西";
        }
        resultText = wd


    }
}